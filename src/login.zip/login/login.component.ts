import { trigger, transition, style, animate } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(-10px)' }),
        animate('0.5s ease-in-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ])
    ])
  ]
})
export class LoginComponent {

  isLogin: boolean = true;
  signupForm: FormGroup;
  loginForm: FormGroup;
  forgotPasswordForm: FormGroup;
  showPassword = false;
  isForgotPassword: boolean = false;
  constructor(private fb: FormBuilder, private router: Router, private toast: ToastrService,) {
    this.signupForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dob: ['', Validators.required],
    });
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.forgotPasswordForm = this.fb.group({
      femail: ['', [Validators.required, Validators.email]]
    });
  }

  get s(): { [key: string]: AbstractControl } {
    return this.signupForm.controls;
  }

  get l(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  get p(): { [key: string]: AbstractControl } {
    return this.forgotPasswordForm.controls;
  }

  toggleForm(isLogin: boolean) {
    // if (isLogin) {
    //   this.signupForm.reset();
    // }
    // else {
    //   this.loginForm.reset();
    // }
    this.isLogin = isLogin;
    this.isForgotPassword = false;
  }

  isPasswordVisible: boolean = false;

  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }
  islogPasswordVisible: boolean = false;
  togglelogPasswordVisibility() {
    this.islogPasswordVisible = !this.islogPasswordVisible;
  }

  onSubmit() {
    if (this.signupForm.valid) {
      this.toast.success('Register Successfully!');
      this.toggleForm(true);
      this.loginForm.get('email')?.setValue(this.signupForm.value.email);
      this.loginForm.get('password')?.setValue(this.signupForm.value.password);
      this.signupForm.reset();
      this.isPasswordVisible = false;
    } else {
      this.signupForm.markAllAsTouched();
    }
  }

  onSubmitLogin() {
    if (this.loginForm.valid) {
      this.loginForm.reset();
      this.islogPasswordVisible = false;
      this.toast.success('Login Successfully!');
      this.router.navigateByUrl('product-list');
    } else {
      this.loginForm.markAllAsTouched();
    }
  }

  // Handle forgot password form submission
  onSubmitForgotPassword() {
    if (this.forgotPasswordForm.valid) {
      this.toast.success('Reset Link Successfully sent to your Mail ID!');
    }
  }

  // Show the forgot password form
  showForgotPasswordForm() {
    this.isLogin = false;
    this.isForgotPassword = true;
  }

  // Show the login form again
  backToLogin() {
    this.isLogin = true;
    this.isForgotPassword = false;
  }

}
